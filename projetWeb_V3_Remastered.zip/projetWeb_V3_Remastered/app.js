const express = require('express');
const session = require('express-session');

const inscriptionRoutes = require('./routes/inscription')
const loginRoutes = require('./routes/login') 

const app = express();

// Permet d'utiliser les fichiers Html
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

// Utilise le style.css
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
// Route par défaut = connexion
app.use('/', loginRoutes);
app.use('/inscription', inscriptionRoutes);

// Utilisation des sessions pour la connexion
const sessionParams = {
  secret: "my_secret",
  maxAge: 24 * 60 * 60 * 1000
};
app.use(session(sessionParams));


// Lance le serveur
app.listen(3000, () => {
    console.log('Server started');
  });