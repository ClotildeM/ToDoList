let form= document.querySelector("form");

let email= form.querySelector('#email');
let password1= form.querySelector('#password1');
let password2= form.querySelector('#password2');

let errormail = form.querySelector("#errormail");
let errormdp = form.querySelector("#errormdp");
let errormdp2 = form.querySelector("#errormdp2");
let msgconf = document.querySelector("#msgconf");

function checkEmptyFiels(){
    if( email.value=='' && password1.value==''){
        errormail.textContent='Veuillez renseigner une adresse e-mail';
        errormdp.textContent='Veuillez renseignez un mot de passe';
    }else{
    }
};

function checkPasswordValidity(){
    if(password1.validity.patternMismatch){
        errormdp.textContent='Veuillez saisir un mot de passe de 6 caractères alphanumériques';
    }else {
        password1.setCustomValidity('');
    };
    if(password2.value!='' && password1.value !=password2.value){
        errormdp2.textContent='Les mots de passe ne correspondent pas';
    } else {
        password1.setCustomValidity('');
    }
    };

function checkEmailValidity(){
    let emailValid=/^[a-zA-Z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$/;
    if(!emailValid.test(email.value)){
        errormail.textContent='Veuillez saisir un adresse e-mail valide';
    }else{
        email.setCustomValidity('');
    }
};

password1.addEventListener('change', checkPasswordValidity, false);
password2.addEventListener('change', checkPasswordValidity, false);
email.addEventListener('change',checkEmailValidity,false);

form.addEventListener('submit', formValidity,false); 

async function formValidity(){
    checkEmptyFiels();
    checkPasswordValidity();
    checkEmailValidity();
    if(!this.checkValidity()){
        event.preventDefault();
    }
}