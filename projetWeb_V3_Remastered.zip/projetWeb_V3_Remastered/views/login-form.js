let form= document.querySelector("form");

let email= form.querySelector('#email');
let password1= form.querySelector('#password1');

let errormail = form.querySelector("#errormail");
let errormdp = form.querySelector("#errormdp");

function checkEmptyFiels(){
    if( email.value=='' && password1.value==''){
        errormail.textContent='Veuillez renseigner une adresse e-mail';
        errormdp.textContent='Veuillez renseignez un mot de passe';
        
    }else{
    }
};

//email.addEventListener('change',checkEmptyFiels,false);

form.addEventListener('submit', formValidity,false); 

async function formValidity(){
    checkEmptyFiels();
    if(!this.checkValidity()){
        event.preventDefault();
    }
}