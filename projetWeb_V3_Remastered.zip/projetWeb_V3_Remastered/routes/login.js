const express = require('express');
const router = express.Router();
const utils = require('../db/utils')

router.get('/', (req, res) => {
    res.render('login', {
  
      });
  });

router.post('/submit', (req,res)=>{

  const form = req.body;
  const sql = "SELECT * FROM UTILISATEUR WHERE emailutilisateur=$1 AND mdpsecurise=$2";
  const params = [form.email, form.password1];

  // utilisation de la base de donnée pour voir si l'utilisateur existe via ExecuteQuery
  utils.executeQuery(sql, params,(err,result)=>{
    if (err) {
      res.status(500).send("erreur :", err);
    } else {
      const userFound = result.rows[0];

      if (userFound) {
        req.session.userId = userFound.id;
        req.session.email = userFound.email;
        res.locals.password1 = userFound.password1;
        res.locals.isAuthentificated = true;

        res.redirect("/login");
      } 
      else {
        res.render("/inscription");
      }
    }
  });
/*
  res.render('inscription',{

  });
  */
});

  module.exports = router;