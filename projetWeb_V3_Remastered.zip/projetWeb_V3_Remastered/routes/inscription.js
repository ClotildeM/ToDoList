const express = require('express');
const router = express.Router();


router.get('/', (req, res) => {
    
  
  res.render('inscription', {

    });
  });
  
  /*
  if(ins.valider()){
    let sql = "INSERT INTO UTILISATEUR(IdUtilisateur, EmailUtilisateur, MdpSecurise) VALUES (Seq_utilisateur.NEXTVAL,emailElt, mdpElt); "
    let params = [req.body.emailElt,req.body.mdpElt];
    

    router.post("/reussie",(req,res)=>{
      executeQuery(sql, params, callback);
    })
    
  }
   */
  module.exports = router;