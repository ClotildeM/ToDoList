DROP TABLE IF EXISTS utilisateur;

CREATE TABLE utilisateur (
    IdUtilisateur SERIAL PRIMARY KEY,
    EmailUtilisateur VARCHAR,
    MdpSecurise VARCHAR
);

INSERT INTO utilisateur(EmailUtilisateur, MdpSecurise) VALUES ('toto@gmail.com', 'Toto!1');

