const utils = {};
const { Pool } = require("pg");;

// Inialisation de la connexion
const pool = new Pool({
  user: "yisjlutb",
  host: "kandula.db.elephantsql.com",
  database: "yisjlutb",
  password: "4iOv1VSs1fDy7Cpb_modrCtzB9XhVscg",
  port: 5432
});

// Execution des commandes SQL
utils.executeQuery = (sql, params, callback) => {
  pool.query(sql, params, callback);
};

module.exports=utils;